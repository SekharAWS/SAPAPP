# Readme file for WEEK 1: INTRODUCTION - ABAP RESTful APPLICATION PROGRAMMING MODEL (RAP)
In week 1, we introduce RAP, its architecture and involved technologies.
Hands-on excersises are starting with unit 5, where you are going to set up your ABAP developement environment and write your first _Hello World_ console app.

    
# HANDS-ON EXERCISES
Find the links to the different hands-on exercises below.

## Week 1 Unit 1: The Big Picture  
There is no hands-on exercise available for this unit.
        
## Week 1 Unit 2: Architecture Overview  
There is no hands-on exercise available for this unit.
    
## Week 1 Unit 3: Involved Technologies
There is no hands-on exercise available for this unit.
        
## Week 1 Unit 4: Introducing SAP Cloud Platform, ABAP Environment 
There is no hands-on exercise available for this unit.
        
## Week 1 Unit 5 Preparing Your ABAP Development Environment 
[Link to the hands-on exercise.](unit5.md)
        
## Week 1 Unit 6: Creating Your First ABAP Cloud Console App
[Link to the hands-on exercise.](unit6.md)
        
## Additional Reading Material
For more information, links to documentation, and more, please visit the [RAP at openSAP information page](https://community.sap.com/topics/cloud-platform-abap-environment/rap-opensap).    

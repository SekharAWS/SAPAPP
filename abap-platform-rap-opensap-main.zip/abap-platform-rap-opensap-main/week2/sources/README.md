# CODE SNIPPETS

The final source codes of all objects created in week 2 (at the end of each unit) is stored in this folder.
   
**Naming Convention:** **W**<_week_number_>**U**<_unit_number_>**\_**<_tadir_type_>**\_**<_object_name_>  

   
**Note:**      
Please note that all occurrences of the placeholder **`####`** used in object names and code snippets shall be replaced with the suffix of your choice during the exercises. The suffix shall contain a maximum of 4 characters. Numbers and letters are allowed.    
Examples: `496`, `1234`, `AB12`, `YZ89`, etc...



